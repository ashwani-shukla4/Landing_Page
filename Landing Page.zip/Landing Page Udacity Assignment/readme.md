# Landing Page

This project is for Udacity's Front End Nanodegree program. HTML and CSS starter code provided by Udacity. 

# Description

This is a basic landing page that uses Javascript to create a NavBar dynamically and to highlight sections when scrolled. The project uses HTML, CSS, and Javascript. 


